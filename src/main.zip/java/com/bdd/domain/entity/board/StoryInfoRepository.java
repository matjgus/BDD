package com.bdd.domain.entity.board;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StoryInfoRepository extends JpaRepository<StoryInfo, Long>{

}